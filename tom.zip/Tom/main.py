import pygame

from tkinter import *
import os

class MyWindow(Tk):

    def __init__(self):
        Tk.__init__(self)

        self.__name = StringVar()

        label = Label(self, text="Enter your name:")
        label.pack()
        self.configure(bg='black')
        name = Entry(self, textvariable=self.__name)
        name.focus_set()
        name.pack()

        button = Button(self, text="snake", command=self.launch_snake)
        button2 = Button(self, text="bomberman", command=self.launch_bomberman)
        button3 = Button(self, text="flappy", command=self.launch_flappy)
        button.pack()
        button2.pack()
        button3.pack()
        self.geometry("800x800")
        self.title(" the legendaries olympus games ")

    def launch_snake(self):
        os.system("python3 snake.py")

    def launch_bomberman(self):
        os.system("cd bomberman-pygame; python3 main.py")

    def launch_flappy(self):
        os.system("cd flappy-bird-pygame; python3 flappybird.py")

window = MyWindow()
window.mainloop()
